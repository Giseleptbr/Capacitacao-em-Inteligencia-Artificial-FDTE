"""
Módulo: logistic_regression.py
Implementação de Regressão Logística Binária e Multinomial (Softmax)
com e sem regularização L2, usando apenas NumPy.

"""

import numpy as np

# ============================================================
# Funções auxiliares
# ============================================================

def sigmoid(z):
    """
    Função logística (sigmoid)
    """
    return 1 / (1 + np.exp(-z))


def softmax(Z):
    """
    Softmax com estabilidade numérica.
    Cada linha de Z representa um exemplo.
    """
    expZ = np.exp(Z - np.max(Z, axis=1, keepdims=True))
    return expZ / np.sum(expZ, axis=1, keepdims=True)


# ============================================================
# Regressão Logística Binária
# ============================================================

class RegressaoLogisticB:
    """
    Regressão Logística Binária implementada do zero.

    Parâmetros:
    - lr: taxa de aprendizado
    - n_iter: número de iterações do gradiente
    - lambda_l2: coeficiente de regularização L2
    """

    def __init__(self, lr=0.01, n_iter=1000, lambda_l2=0.0):
        self.lr = lr
        self.n_iter = n_iter
        self.lambda_l2 = lambda_l2
        self.w = None
        self.b = None

    def fit(self, X, y):
        """
        Ajusta o modelo pela minimização da perda logística.
        X: matriz (n_samples, n_features)
        y: vetor binário (0 ou 1)
        """
        n_samples, n_features = X.shape

        self.w = np.zeros(n_features)
        self.b = 0.0

        for _ in range(self.n_iter):
            z = np.dot(X, self.w) + self.b
            y_hat = sigmoid(z)

            # Gradientes
            dw = (1 / n_samples) * np.dot(X.T, (y_hat - y)) + self.lambda_l2 * self.w
            db = (1 / n_samples) * np.sum(y_hat - y)

            # Atualização
            self.w -= self.lr * dw
            self.b -= self.lr * db

    def predict_proba(self, X):
        """
        Probabilidade estimada P(y=1 | X)
        """
        return sigmoid(np.dot(X, self.w) + self.b)

    def predict(self, X):
        """
        Predição binária 0/1
        """
        return (self.predict_proba(X) >= 0.5).astype(int)
