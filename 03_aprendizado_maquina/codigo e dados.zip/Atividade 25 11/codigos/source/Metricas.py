import numpy as np
import matplotlib.pyplot as plt

class Metricas:
    def __init__(self, model=None):
        self.model = model

    # ---------------------------------------------------------
    # MATRIZ DE CONFUSÃO PARA CADA SAÍDA BINÁRIA
    # ---------------------------------------------------------
    def confusion_matrix(self, Y_true, Y_pred):
        Y_true = Y_true.astype(int)
        Y_pred = Y_pred.astype(int)

        n_out = Y_true.shape[1]
        cms = []

        for k in range(n_out):
            cm = np.zeros((2, 2), dtype=int)

            for i in range(len(Y_true)):
                t = Y_true[i, k]
                p = Y_pred[i, k]
                cm[t, p] += 1

            cms.append(cm)

        return cms

    # ---------------------------------------------------------
    # PRECISION, RECALL, F1 E F1-MACRO
    # ---------------------------------------------------------
    def f1score(self, Y_true, Y_pred):
        cms = self.confusion_matrix(Y_true, Y_pred)
        scores = []

        for cm in cms:
            TN, FP = cm[0, 0], cm[0, 1]
            FN, TP = cm[1, 0], cm[1, 1]

            # Classe positiva (1)
            prec_pos = TP / (TP + FP) if (TP + FP) > 0 else 0
            rec_pos  = TP / (TP + FN) if (TP + FN) > 0 else 0
            f1_pos = (2 * prec_pos * rec_pos / (prec_pos + rec_pos)
                      if (prec_pos + rec_pos) > 0 else 0)

            # Classe negativa (0)
            prec_neg = TN / (TN + FN) if (TN + FN) > 0 else 0
            rec_neg  = TN / (TN + FP) if (TN + FP) > 0 else 0
            f1_neg = (2 * prec_neg * rec_neg / (prec_neg + rec_neg)
                      if (prec_neg + rec_neg) > 0 else 0)

            f1_macro = (f1_pos + f1_neg) / 2

            scores.append({
                "precision_pos": prec_pos,
                "recall_pos": rec_pos,
                "f1_pos": f1_pos,
                "precision_neg": prec_neg,
                "recall_neg": rec_neg,
                "f1_neg": f1_neg,
                "f1_macro": f1_macro
            })

        return scores

    # ---------------------------------------------------------
    # ACURÁCIA GLOBAL
    # ---------------------------------------------------------
    def accuracy(self, Y, Y_pred_prob):
        if self.model.activation == "sigmoid":
            Y_pred = (Y_pred_prob >= 0.5).astype(int)
        elif self.model.activation == "tanh":
            Y_pred = (Y_pred_prob >= 0).astype(int)
        else:
            Y_pred = Y_pred_prob

        correct = np.sum(Y_pred == Y)
        total = np.prod(Y.shape)

        return correct / total

    # ---------------------------------------------------------
    # CURVA ROC MANUAL
    # ---------------------------------------------------------
    def roc_curve_manual(self, y_true, y_scores):
        idx = np.argsort(-y_scores)
        y_true = y_true[idx]
        y_scores = y_scores[idx]

        thresholds = np.unique(y_scores)

        P = np.sum(y_true)
        N = len(y_true) - P

        TPR, FPR = [], []

        for thr in thresholds:
            y_pred = (y_scores >= thr).astype(int)

            TP = np.sum((y_pred == 1) & (y_true == 1))
            FP = np.sum((y_pred == 1) & (y_true == 0))
            FN = np.sum((y_pred == 0) & (y_true == 1))
            TN = np.sum((y_pred == 0) & (y_true == 0))

            TPR.append(TP / P if P > 0 else 0)
            FPR.append(FP / N if N > 0 else 0)

        return np.array(FPR), np.array(TPR), thresholds

    # ---------------------------------------------------------
    # AUC PELO MÉTODO DO TRAPÉZIO
    # ---------------------------------------------------------
    def auc_from_roc(self, FPR, TPR):
        return np.trapz(TPR, FPR)

    # ---------------------------------------------------------
    # ROC + AUC PARA TODAS AS SAÍDAS
    # ---------------------------------------------------------
    def roc_all(self, Y_true, Y_scores):
        results = []

        for k in range(Y_true.shape[1]):
            FPR, TPR, thr = self.roc_curve_manual(Y_true[:, k], Y_scores[:, k])
            auc = self.auc_from_roc(FPR, TPR)
            results.append({"FPR": FPR, "TPR": TPR, "thr": thr, "auc": auc})

        return results

    # ---------------------------------------------------------
    # GRÁFICO DA CURVA ROC
    # ---------------------------------------------------------
    def plot_roc(self, FPR, TPR, auc, title="Curva ROC"):
        plt.figure(figsize=(6, 5))
        plt.plot(FPR, TPR, label=f"AUC = {auc:.4f}", linewidth=2)
        plt.plot([0, 1], [0, 1], 'k--')
        plt.xlabel("FPR")
        plt.ylabel("TPR")
        plt.title(title)
        plt.grid(True)
        plt.legend()
        plt.show()
