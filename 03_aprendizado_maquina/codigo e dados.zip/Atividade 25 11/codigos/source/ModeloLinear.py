import numpy as np

class ModeloLinear:
    def __init__(self, tipo=1, lamb=100, alpha=0.5 ):
        self.tipo = tipo #1 - modelo linear tradicional,
                         #2 - Modelo linear norma 2,
                         #3 - modelo linear norma 1 - usando algoritmo ISTA
                         #4 - modelo linear norma 1 - usando algoritmo FISTA
                         #5 - modelo linear elastic net - usando algoritmo ISTA
                         #6 - modelo linear elastic net - usando algoritmo FISTA
        self.lamb = lamb # parametro de regularização norma
        self.alpha  = alpha
        self.X = None
        self.Y = None
        self.max_iter = 200
        self.W = None

    def soft_threshold(v, t):
        return np.sign(v) * np.maximum(np.abs(v) - t, 0.0)

    def fit(self, X, y):
        if self.tipo == 1:
            self.ridge_closed_form(X, y)
        elif self.tipo == 2:
            self.ridge_closed_forml2(X, y)
        elif self.tipo == 3:
            self.lasso_ISTA(X, y)

        elif self.tipo == 4:
            self.lasso_FISTA(X, y)

        elif self.tipo == 5:
            self.enet_ISTA(X, y)

        elif self.tipo == 6:
            self.enet_FISTA(X, y)

        else:
            error("parametro tipo incorreto")
    # ---------------------------------------------------------
    def ridge_closed_form(self,X, y):
        self.W = np.linalg.inv(X.T @ X ) @ X.T @ y

    def ridge_closed_forml2(self,X, y):
        lam = self.lamb
        n_features = X.shape[1]
        I = np.eye(n_features)
        self.W = np.linalg.inv(X.T @ X + lam * I) @ X.T @ y


    # ---------------------------------------------------------
    # Função objetivo LASSO
    # ---------------------------------------------------------
    def lasso_objective(self,X, y, theta, lam):
        return 0.5 * np.linalg.norm(X @ theta - y)**2 + lam * np.linalg.norm(theta, 1)

    # ---------------------------------------------------------
    # Estima Lipschitz constant L = max eigenvalue(X^T X)
    # (método da potência)
    # ---------------------------------------------------------
    def lasso_estimate_L(self,X, max_iter=100):
        b = np.random.randn(X.shape[1])
        b /= np.linalg.norm(b)

        for _ in range(max_iter):
            b = X.T @ (X @ b)
            b /= np.linalg.norm(b)
        return (b @ (X.T @ (X @ b)))


    # ---------------------------------------------------------
    # ISTA
    # ---------------------------------------------------------
    def lasso_ISTA(self,X, y):
        lam = self.lamb
        max_iter = self.max_iter

        n, p = X.shape
        L = self.lasso_estimate_L(X)
        alpha = 1.0 / L

        theta = np.zeros(p)
        history = []

        for _ in range(max_iter):
            grad = X.T @ (X @ theta - y)
            theta = self.soft_threshold(theta - alpha * grad, alpha * lam)
            history.append(self.lasso_objective(X, y, theta, lam))
        #return theta, history
        self.W = theta
        self.history = history

    # ---------------------------------------------------------
    # FISTA
    # ---------------------------------------------------------
    def lasso_FISTA(X, y):
        lam = self.lamb
        max_iter = self.max_iter
        n, p = X.shape
        L = estimate_L(X)
        alpha = 1.0 / L

        theta = np.zeros(p)
        z = theta.copy()
        t = 1.0

        history = []

        for _ in range(max_iter):
            grad = X.T @ (X @ z - y)
            theta_new = self.soft_threshold(z - alpha * grad, alpha * lam)
            t_new = (1 + np.sqrt(1 + 4 * t**2)) / 2
            z = theta_new + (t - 1) / t_new * (theta_new - theta)
            theta = theta_new
            t = t_new
            history.append(self.lasso_objective(X, y, theta, lam))
        #return theta, history
        self.W = theta
        self.history = history


    # ---------------------------------------------------------
    # Função objetivo Elastic Net
    # ---------------------------------------------------------
    def enet_objective(self,X, y, theta, lam, alpha):
        l1 = lam * alpha * np.linalg.norm(theta, 1)
        l2 = lam * (1 - alpha) * 0.5 * np.linalg.norm(theta, 2)**2
        return 0.5 * np.linalg.norm(X @ theta - y)**2 + l1 + l2

    # ---------------------------------------------------------
    # Estimar L (Lipschitz constant)
    # ---------------------------------------------------------
    def enet_estimate_L(self,X, iters=100):
        b = np.random.randn(X.shape[1])
        b /= np.linalg.norm(b)
        for _ in range(iters):
            b = X.T @ (X @ b)
            b /= np.linalg.norm(b)
        return b @ (X.T @ (X @ b))


    # ---------------------------------------------------------
    # ISTA para Elastic Net
    # ---------------------------------------------------------
    def enet_ISTA(self,X, y):
        lam = self.lamb
        max_iter = self.max_iter
        alpha = self.alpha
        n, p = X.shape

        L = self.enet_estimate_L(X)
        L_total = L + lam * (1 - alpha)
        eta = 1.0 / L_total

        theta = np.zeros(p)
        history = []

        for _ in range(max_iter):
            grad = X.T @ (X @ theta - y) + lam * (1 - alpha) * theta
            theta = self.soft_threshold(theta - eta * grad, eta * lam * alpha)

            history.append(self.enet_objective(X, y, theta, lam, alpha))

        #return theta, history
        self.W = theta
        self.history = history

    # ---------------------------------------------------------
    # FISTA para Elastic Net
    # ---------------------------------------------------------
    def enet_FISTA(self, X, y):
        lam = self.lamb
        max_iter = self.max_iter
        alpha = self.alpha

        n, p = X.shape

        L = self.enet_estimate_L(X)
        L_total = L + lam * (1 - alpha)
        eta = 1.0 / L_total

        theta = np.zeros(p)
        z = theta.copy()
        t = 1.0

        history = []

        for _ in range(max_iter):
            grad = X.T @ (X @ z - y) + lam * (1 - alpha) * z

            theta_new = soft_threshold(z - eta * grad, eta * lam * alpha)

            t_new = (1 + np.sqrt(1 + 4 * t**2)) / 2
            z = theta_new + (t - 1) / t_new * (theta_new - theta)

            theta = theta_new
            t = t_new
            history.append(enet_objective(X, y, theta, lam, alpha))

        #return theta, history
        self.W = theta
        self.history = history

    def predict(self,X):
        return X @ self.W

