"""
Módulo: logistic_regression.py
Implementação de Regressão Logística  Multinomial (Softmax)
com e sem regularização L2, usando apenas NumPy.

Classes:
- LogisticRegressionBinary
- LogisticRegressionMultinomial
"""

import numpy as np


# ============================================================
# Funções auxiliares
# ============================================================

def sigmoid(z):
    """
    Função logística (sigmoid)
    """
    return 1 / (1 + np.exp(-z))


def softmax(Z):
    """
    Softmax com estabilidade numérica.
    Cada linha de Z representa um exemplo.
    """
    expZ = np.exp(Z - np.max(Z, axis=1, keepdims=True))
    return expZ / np.sum(expZ, axis=1, keepdims=True)


# ============================================================
# Regressão Logística Multinomial (Softmax Regression)
# ============================================================

class RegressaoLogisticM:
    """
    Regressão Logística Multinomial (Softmax Regression).

    Parâmetros:
    - lr: taxa de aprendizado
    - n_iter: número de iterações
    - lambda_l2: regularização L2
    """

    def __init__(self, lr=0.01, n_iter=10, lambda_l2=0.0):
        self.lr = lr
        self.n_iter = n_iter
        self.lambda_l2 = lambda_l2
        self.W = None
        self.b = None
        self.classes_ = None

    def fit(self, X, y):
        """
        Ajuste do modelo via gradiente descendente.

        X: matriz (n_samples, n_features)
        y: vetor de classes inteiras {0,1,...,K}
        """
        n_samples, n_features = X.shape
        self.classes_ = np.unique(y)
        n_classes = len(self.classes_)

        # One-hot de y
        Y = np.eye(n_classes)[y]

        # Parâmetros
        self.W = np.zeros((n_features, n_classes))
        self.b = np.zeros((1, n_classes))

        for _ in range(self.n_iter):
            #print(self.n_iter)
            Z = np.dot(X, self.W) + self.b
            Y_hat = softmax(Z)

            # Gradientes
            dW = (1 / n_samples) * np.dot(X.T, (Y_hat - Y)) + self.lambda_l2 * self.W
            db = (1 / n_samples) * np.sum(Y_hat - Y, axis=0, keepdims=True)

            # Atualização
            self.W -= self.lr * dW
            self.b -= self.lr * db

    def predict_proba(self, X):
        """
        Retorna distribuições de probabilidade para cada classe.
        """
        return softmax(np.dot(X, self.W) + self.b)

    def predict(self, X):
        """
        Predição da classe mais provável.
        """
        return np.argmax(self.predict_proba(X), axis=1)