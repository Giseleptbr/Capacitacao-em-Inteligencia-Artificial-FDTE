import numpy as np

class rede_rbf:
    def __init__(self, n_centers, sigma=None):
        self.n_centers = n_centers
        self.centers = None
        self.sigma = sigma
        self.weights = None

    def _gaussian(self, X, c):
        """Base radial Gaussiana: exp(-||x - c||^2 / (2 sigma^2))"""
        return np.exp(-np.linalg.norm(X - c, axis=1)**2 / (2 * self.sigma**2))

    def _design_matrix(self, X):
        """Cria a matriz Φ com as ativações das bases radiais"""
        Phi = np.zeros((X.shape[0], self.n_centers))
        for i, c in enumerate(self.centers):
            Phi[:, i] = self._gaussian(X, c)
        return Phi

    def _choose_centers(self, X):
        """Escolhe centros aleatórios (simples, sem K-means)"""
        rnd_idx = np.random.choice(len(X), self.n_centers, replace=False)
        self.centers = X[rnd_idx]

    def fit(self, X, y):
        """Treinamento com pseudoinversa"""
        self._choose_centers(X)

        # Heurística para sigma: média das distâncias entre centros
        if self.sigma is None:
            d = [np.linalg.norm(c1 - c2) for c1 in self.centers for c2 in self.centers]
            self.sigma = np.mean(d)

        Phi = self._design_matrix(X)

        # Pesos via pseudoinversa
        self.weights = np.linalg.pinv(Phi) @ y

    def predict(self, X):
        Phi = self._design_matrix(X)
        return Phi @ self.weights


