#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#Implementa o perceptron com multiplas entradas e multiplas saidas
# Disciplina: Aprendizado de Maquina
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import numpy as np

class Perceptron:
    def __init__(self, input_dim, output_dim, lr=0.01, activation="sigmoid"):
        """
        Perceptron diferenciável de 1 camada
        activation ∈ {"sigmoid", "tanh", "relu", "linear"}
        """
        self.W = np.random.randn(input_dim, output_dim) * 0.01
        self.b = np.zeros(output_dim)
        self.lr = lr
        self.activation = activation

    # -------------------------------
    # Funções de ativação
    # -------------------------------
    def _activate(self, z):
        if self.activation == "sigmoid":
            return 1 / (1 + np.exp(-z))
        elif self.activation == "tanh":
            return np.tanh(z)
        elif self.activation == "relu":
            return np.maximum(0, z)
        elif self.activation == "linear":
            return z
        else:
            raise ValueError("Ativação desconhecida.")

    # Derivadas para backprop
    def _dactivate(self, z):
        if self.activation == "sigmoid":
            s = 1 / (1 + np.exp(-z))
            return s * (1 - s)
        elif self.activation == "tanh":
            return 1 - np.tanh(z)**2
        elif self.activation == "relu":
            return (z > 0).astype(float)
        elif self.activation == "linear":
            return np.ones_like(z)

    # -------------------------------
    # Predição
    # -------------------------------
    def predict(self, X):
        z = X @ self.W + self.b
        return self._activate(z)

    # -------------------------------
    # Treinamento (Gradiente Total)
    # -------------------------------
    def fit(self, X, Y, epochs=50):
        n_samples = X.shape[0]

        for epoch in range(epochs):
            for i in range(n_samples):
                x = X[i]
                y = Y[i]

                # forward
                z = x @ self.W + self.b
                y_pred = self._activate(z)

                # erro
                error = y - y_pred

                # gradiente da perda wrt z
                dz = -error * self._dactivate(z)

                # gradientes
                dW = np.outer(x, dz)
                db = dz

                # atualização
                self.W -= self.lr * dW
                self.b -= self.lr * db

            if epoch % 10 == 0:
                print(f"Epoch {epoch}, Loss={np.mean(error**2):.6f}")


    # ----------------------------------------------------
    # Converte probabilidades para classes discretas
    # ----------------------------------------------------
    def predict_classes(self, X):
        y_pred = self.predict(X)

        if self.activation == "sigmoid":
            return (y_pred >= 0.5).astype(int)
        elif self.activation == "tanh":
            return (y_pred >= 0).astype(int)
        else:
            raise ValueError("Para matriz de confusão, use ativação sigmoid ou tanh.")


