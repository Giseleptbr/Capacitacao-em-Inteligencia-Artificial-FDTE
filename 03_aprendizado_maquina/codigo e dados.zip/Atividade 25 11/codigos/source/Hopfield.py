import numpy as np
import matplotlib.pyplot as plt

class Hopfield:

    def __init__(self):
        self.W = None
        self.P = None
        self.K = None
        self.N = None

        # colormap MATLAB: [1 1 1; 0 0 0]
        self.map_colors = np.array([
            [1, 1, 1],   # 0 -> branco
            [0, 0, 0]    # 1 -> preto
        ], dtype=float)

    # -------------------------------------------------------------
    # Função para exibir qualquer imagem vinda do arquivo/Hopfield
    # Convertendo sempre para 0 e 1 (solução do erro)
    # -------------------------------------------------------------
    def show_image(self, x):
        # GARANTIA ABSOLUTA:
        # convertemos qualquer valor (-1, 0, 1, 2, etc.) para 0 ou 1
        img = (x > 0).astype(int)


        plt.imshow(self.map_colors[img], interpolation="nearest")
        plt.axis("off")
        plt.show(block=False)
        plt.pause(0.5)
        plt.close()

    # -------------------------------------------------------------
    # Equivalente ao carrega()
    # -------------------------------------------------------------
    def fit(self, datafile):
        letras = np.loadtxt(datafile)

        self.P = letras.T
        self.K, self.N = letras.shape

        print("\nMostrando padrões originais...")
        self.show(letras)

        print("\nTreinando matriz W...")
        self.W = self.train(self.P)

        print("\nVerificando memória...")
        self.check_memory(self.P, self.W)

        print("\nPredizendo padrões ruidosos...")
        self.predict(self.P, self.W)

    # -------------------------------------------------------------
    # Equivalente à função mostra()
    # -------------------------------------------------------------
    def show(self, letras):
        for i in range(self.K):
            x = letras[i].reshape(20, 20).T
            self.show_image(x)

    # -------------------------------------------------------------
    # Equivalente à função treina()
    # -------------------------------------------------------------
    def train(self, P):
        return P @ np.linalg.inv(P.T @ P) @ P.T

    # -------------------------------------------------------------
    # Equivalente à função verifica_memoria()
    # -------------------------------------------------------------
    def check_memory(self, P, W):
        print("\n--- Verificando memória ---")
        for i in range(self.K):
            Yant = P[:, i]
            Ynew = np.sign(W @ Yant)
            cont = 1

            while np.linalg.norm(Yant - Ynew) > 0:
                cont += 1
                Yant = Ynew
                Ynew = np.sign(W @ Yant)

            x = Ynew.reshape(20, 20).T
            self.show_image(x)
            print(f"Convergiu em {cont} passos.")

    # -------------------------------------------------------------
    # Equivalente à função prediz()
    # -------------------------------------------------------------
    def predict(self, P, W):

        print("\nGerando padrões ruidosos...")
        r = 0.7
        Pr = P.copy()

        # Aplicar ruído
        for i in range(self.K):
            for j in range(self.N):
                if np.random.rand() < r:
                    Pr[j, i] = -Pr[j, i]  # flip de sinal

        # Mostrar padrões com ruído
        for i in range(self.K):
            x = Pr[:, i].reshape(20, 20).T
            self.show_image(x)

        # ---------------------------------------------------------
        # Atualização Síncrona
        # ---------------------------------------------------------
        print("\nSíncrono:")
        for i in range(self.K):
            Yant = Pr[:, i]
            Ynew = np.sign(W @ Yant)
            cont = 1

            while np.linalg.norm(Yant - Ynew) > 0:
                cont += 1
                Yant = Ynew
                Ynew = np.sign(W @ Yant)

            x = Ynew.reshape(20, 20)
            self.show_image(x)
            print(f"Passos (síncrono): {cont}")

        # ---------------------------------------------------------
        # Atualização Assíncrona
        # ---------------------------------------------------------
        print("\nAssíncrono:")
        for i in range(self.K):
            Yant = Pr[:, i]
            Yaux = np.sign(W @ Yant)
            Ynew = Yant.copy()
            pos = np.random.randint(self.N)
            Ynew[pos] = Yaux[pos]
            cont = 1

            while np.linalg.norm(Yant - Yaux) > 0:
                cont += 1
                Yant = Ynew.copy()
                Yaux = np.sign(W @ Yant)
                pos = np.random.randint(self.N)
                Ynew[pos] = Yaux[pos]

            x = Ynew.reshape(20, 20).T
            self.show_image(x)
            print(f"Passos (assíncrono): {cont}")
