import numpy as np
import matplotlib.pyplot as plt


class MLP:
    """
    Implementação de um MLP simples:
    - 1 camada oculta (ativação sigmoide)
    - 1 camada de saída linear
    - Treinamento por gradiente com busca linear calc_alfa()

    Equivalente ao código MATLAB fornecido.
    """

    def __init__(self, input_dim, hidden_dim, output_dim):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim

        # Pesos como randn igual MATLAB
        self.A = np.random.randn(hidden_dim, input_dim + 1)
        self.B = np.random.randn(output_dim, hidden_dim + 1)

    # ---------------------------------------------------------
    # Forward: calcula saída Y
    # ---------------------------------------------------------
    def forward(self, X):
        N = X.shape[0]
        Xb = np.hstack([X, np.ones((N, 1))])  # adiciona bias

        self.Zin = Xb @ self.A.T
        self.Z = 1 / (1 + np.exp(-self.Zin))  # sigmoide

        Zb = np.hstack([self.Z, np.ones((N, 1))])
        self.Yin = Zb @ self.B.T

        # saída linear (como MATLAB)
        return self.Yin

    # ---------------------------------------------------------
    # Gradientes dJ/dA e dJ/dB
    # ---------------------------------------------------------
    def calc_grad(self, X, Yd,A, B):
        N = X.shape[0]

        # Forward
        Xb = np.hstack([X, np.ones((N, 1))])
        self.Zin = Xb @ A.T
        self.Z = 1 / (1 + np.exp(-self.Zin))  # sigmoide
        Zb = np.hstack([self.Z, np.ones((N, 1))])
        self.Yin = Zb @ B.T
        Y = self.Yin

        erro = Y - Yd

        # Gradiente da camada de saída
        dJdB = (1 / N) * (erro.T @ Zb)

        # Para dJ/dA
        dJdZ = erro @  B[:, :-1]  # remove bias

        dZ = self.Z * (1 - self.Z)
        dJdA = (1 / N) * (dJdZ * dZ).T @ Xb

        return dJdA, dJdB

    # ---------------------------------------------------------
    # Busca linear calc_alfa (versão fiel ao MATLAB)
    # ---------------------------------------------------------
    def calc_alfa(self, X, Yd, dirA, dirB):
        epsilon = 1e-3
        hlmin = 1e-3

        alfa_l = 0
        alfa_u = np.random.rand()

        # Teste inicial
        An = self.A + alfa_u * dirA
        Bn = self.B + alfa_u * dirB

        # Gradiente no novo ponto
        dJdA, dJdB = self.calc_grad(X, Yd,An, Bn)
        g = np.concatenate([dJdA.ravel(), dJdB.ravel()])
        d = np.concatenate([dirA.ravel(), dirB.ravel()])

        hl = np.dot(g, d)

        # Expande até mudar sinal
        while hl < 0:
            alfa_u *= 2

            An = self.A + alfa_u * dirA
            Bn = self.B + alfa_u * dirB

            # recalcula gradiente
            Ytmp = self.forward(X)
            dJdA, dJdB = self.calc_grad(X, Yd, An, Bn)
            g = np.concatenate([dJdA.ravel(), dJdB.ravel()])
            hl = np.dot(g, d)

        alfa_m = (alfa_l + alfa_u) / 2
        itmax = int(np.ceil(np.log((alfa_u - alfa_l) / epsilon)))
        it = 0

        while abs(hl) > hlmin and it < itmax:
            it += 1

            An = self.A + alfa_m * dirA
            Bn = self.B + alfa_m * dirB

            # gradiente no ponto testado
            dJdA, dJdB = self.calc_grad(X, Yd,An,Bn)
            g = np.concatenate([dJdA.ravel(), dJdB.ravel()])
            hl = np.dot(g, d)

            if hl > 0:
                alfa_u = alfa_m
            elif hl < 0:
                alfa_l = alfa_m
            else:
                break

            alfa_m = (alfa_l + alfa_u) / 2

        return alfa_m

    # ---------------------------------------------------------
    # Treinamento
    # ---------------------------------------------------------
    def fit(self, X, Yd, epochs=200):
        N = X.shape[0]
        errors = []

        for epoch in range(epochs):
            print(epoch)
            # gradiente
            dJdA, dJdB = self.calc_grad(X, Yd,self.A,self.B)

            dirA = -dJdA
            dirB = -dJdB

            # busca linear
            #alfa = self.calc_alfa(X, Yd, dirA, dirB)
            alfa = 0.01
            # atualização
            self.A += alfa * dirA
            self.B += alfa * dirB

            # erro
            Y = self.forward(X)
            erro = Y - Yd
            EQM = (1 / N) * np.sum(erro * erro)

            errors.append(EQM)

            print(f"Época {epoch}  EQM={EQM:.6f}  alfa={alfa:.6f}")

            if EQM < 1e-5:
                break

        # gráfico do erro
        plt.plot(errors)
        plt.xlabel("épocas")
        plt.ylabel("EQM")
        plt.title("Treinamento MLP")
        plt.grid()
        plt.show()

    # ---------------------------------------------------------
    # Predição
    # ---------------------------------------------------------
    def predict(self, X):
        return self.forward(X)
