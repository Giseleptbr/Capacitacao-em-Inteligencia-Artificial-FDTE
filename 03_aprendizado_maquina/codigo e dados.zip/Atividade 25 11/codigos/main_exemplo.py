import numpy as np
from source.Perceptron import Perceptron
from source.rede_rbf import rede_rbf as rbf
from source.Metricas import Metricas
from source.Hopfield import Hopfield as hopfield
from source.MLP import MLP as mlp
from source.ModeloLinear import ModeloLinear as mlinear
from source.RegressaoLogisticB import RegressaoLogisticB as rlogisb
from source.RegressaLogisticM import RegressaoLogisticM as rlogism


import numpy as np

if __name__ == "__main__":


    #================================================================================
    # ==================Logistica Binomial+++++++++++++++++++++++++++++++++++++++++++++++++++
    #============================================================================

    X = np.array([[0], [1], [2], [3]])
    Y = np.array([0, 0, 1, 1])
    model=rlogisb()
    model.fit(X, Y)
    model.predict(X)


    #================================================================================
    # ==================Regressão Logisica Multinomial+++++++++++++++++++++++++++++++++++++++++++++++++
    #============================================================================

    X = np.array([
        [0, 0],
        [0, 1],
        [1, 0],
        [1, 1]
    ])

    # OR e AND
    Y = np.array([0, 0, 1, 2])

    model = rlogism()
    model.fit(X, Y)
    print(model.predict(X))


    #================================================================================
    # ==================Perceptron++++++++++++++++++++++++++++++++++++++++++++++++++
    #============================================================================

    # OR e AND
    X = np.array([
        [0, 0],
        [0, 1],
        [1, 0],
        [1, 1]
    ])
    Y = np.array([
        [1, 0],
        [0, 1],
        [0, 1],
        [1, 0]
    ])

    model = Perceptron(
        input_dim=2,
        output_dim=2,
        lr=0.1,
        activation="sigmoid"
    )

    print("\n=== ANTES DO TREINO ===")
    print(model.predict(X))


    # Treinamento
    model.fit(X, Y, epochs=500)

    print("\n=== DEPOIS DO TREINO ===")
    Y_pred_prob = model.predict(X)
    print(Y_pred_prob)

    # Preparar métricas
    met = Metricas(model)
    Y_pred_classes = model.predict_classes(X)

    cms = met.confusion_matrix(Y, Y_pred_classes)
    f1_scores = met.f1score(Y_pred_classes, Y)
    print("\n=== Matrizes de Confusão ===")
    for i, cm in enumerate(cms):
        print(f"Saída {i}:")
        print(cm)
        print()

    # Acurácia
    acc = met.accuracy(Y, Y_pred_prob)
    print(f"\nAcurácia final: {acc*100:.2f}%")


    # F1
    scores = met.f1score(Y, Y_pred_classes)
    print("\n=== Métricas por saída ===")
    for i, s in enumerate(scores):
        print(f"\nSaída {i}:")
        print(f"  F1_macro = {s['f1_macro']:.4f}")
        print(f"  F1_pos   = {s['f1_pos']:.4f}")
        print(f"  F1_neg   = {s['f1_neg']:.4f}")

    # ROC + AUC
    roc_data = met.roc_all(Y, Y_pred_prob)

    for i, r in enumerate(roc_data):
        print(f"\nSaída {i}: AUC = {r['auc']:.4f}")
        met.plot_roc(r["FPR"], r["TPR"], r["auc"], title=f"ROC saída {i}")


    #================================================================================
    # ==================RBF+++++++++++++++++++++++++++++++++++++++++++++++++++
    #================================================================================
    # Dados simples 1D
    X = np.linspace(-3, 3, 50).reshape(-1, 1)
    y = np.sin(X) + 0.1*np.random.randn(50, 1)

    # Cria modelo
    rbfnet = rbf(n_centers=10)

    # Treina
    rbfnet.fit(X, y)

    # Prediz
    y_pred = rbfnet.predict(X)

    print("Centros:\n", rbfnet.centers)
    print("Pesos:\n", rbfnet.weights)

    # ================================================================================
    # ==================MLP+++++++++++++++++++++++++++++++++++++++++++++++++++
    # ================================================================================
    #   Exemplo simples
    X = np.random.rand(100, 2)
    Yd = np.random.rand(100, 1)

    # Cria rede
    model = mlp(input_dim=2, hidden_dim=5, output_dim=1)

    # Treina
    model.fit(X, Yd, epochs=20)

# Prediz
Y = model.predict(X)

print(Y[:10])

#+++++++++++++++++++++++++++Rede Hopfield
#hop = hopfield()
#hop.fit("letras.dat")

